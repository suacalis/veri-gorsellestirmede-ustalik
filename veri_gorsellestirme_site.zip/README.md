# Veri Görselleştirmede Ustalık — Türkçe etkileşimli sürüm

*Master Data Visualization* (matplotlib, seaborn ve plotly) kitabının 18 bölümü ve 5 ekinin Türkçe, tarayıcıda çalışan sürümü.

- **index.html**: ana sayfa. Tüm bölümleri gruplu kartlarla listeler ve bütün sitede arar (başlık, metin, kod, tablo).
- **bolum01 … bolum18**: bölüm sayfaları. Kod hücreleri tarayıcıda **Pyodide** ile çalışır. Her sayfada veri dosyaları gömülüdür; ayrıca sayfa içi arama (Ctrl+K), içindekiler ve etkileşimli sınav vardır.
- **ek_a … ek_e**: Sınav Cevapları, Grafik Seçici, Komut Başvurusu, Kontrol Listesi, İleri Okuma.

## GitHub Pages'te yayınlama

1. GitHub'da yeni bir depo açın (ör. `veri-gorsellestirme`).
2. Bu klasördeki **tüm dosyaları** deponun köküne yükleyin: `index.html`, 23 sayfa, `README.md` ve `.nojekyll`.
3. Deponun **Settings → Pages** bölümünde *Source* için `Deploy from a branch` seçin. Dal olarak `main`, klasör olarak `/ (root)` seçip kaydedin.
4. Birkaç dakika sonra site `https://KULLANICI.github.io/veri-gorsellestirme/` adresinde açılır.

Sayfalar tek dosyalıktır ve sunucu gerektirmez. Python, CodeMirror ve plotly.js CDN'den yüklendiği için internet bağlantısı gerekir.

Tarayıcıdaki sürümler kitaptakilerden eskidir: Pyodide 0.27 ile matplotlib 3.8, pandas 2.2 ve plotly 5.24 gelir. Kitabın kodları bu sürümlerde çalışacak biçimde uyarlanmıştır.
